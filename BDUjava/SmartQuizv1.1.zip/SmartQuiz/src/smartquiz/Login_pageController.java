package smartquiz;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class Login_pageController implements Initializable {

    
    //signupForm here
    @FXML
    private BorderPane signupForm;
    @FXML
    private TextField su_email;
    @FXML
    private PasswordField su_confirmPassword1;
    @FXML
    private PasswordField su_confirmPassword2;
    @FXML
    private Button su_signup;
    
    
    //login Form
    @FXML
    private BorderPane loginForm;
    @FXML
    private TextField u_email;
    @FXML
    private PasswordField u_password;
    @FXML
    private RadioButton u_showPassword;
    @FXML
    private Button u_forgotPassword;
    @FXML
    private Button u_login;
    
    
    //go login to signup or
    
    @FXML
    private Button su_alreadyAccount;
    @FXML
    private Button su_registerAccount;
    @FXML
    private Button u_registerAccount;
    @FXML
    private Button u_createAccount;
    
    
    
    
    

    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    //On action browse other page (loginForm , singupForm)
    
    @FXML
    private void goSignupForm(ActionEvent event) {
        loginForm.setVisible(false);
        signupForm.setVisible(true);        
    }

    @FXML
    private void goLoginForm(ActionEvent event) {
        loginForm.setVisible(true);
        signupForm.setVisible(false);  
    }

    // forgot and show password
    @FXML
    private void showPassword(ActionEvent event) {
    }

    @FXML
    private void forgotPassword(ActionEvent event) {
    }
    
    // login or signup
    
    
    public void loginAccount() {
        System.out.println("Login ok");
    }

    
    public void signupAccount() {
        System.out.println("Signup ok");
    }
    
}
